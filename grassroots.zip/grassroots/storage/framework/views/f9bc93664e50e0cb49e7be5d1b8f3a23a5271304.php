<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
     <!-- tailwindcss cdn link -->
     <script src="https://cdn.tailwindcss.com"></script>

      <!-- CSS file -->
    <link rel="stylesheet" href="<?php echo e(asset('css/hstyle.css')); ?>">
    
    </head>


    
<body class="flex justify-center mt-2">

   <!-- start topbar part -->
   <nav class="w-[1300px] h-[100px] bg-black">
<div class="mx-auto flex items-center">


  <div>
   <img src="/img/logo3.png" class="mt-3 ml-12">
  </div>


  <div>
   <ul class="flex space-x-4 list-none ml-48 list-header">
        <li><a href="#" class="text-white"></a></li>
        <li><a href="#" class="text-white">Home</a></li>&nbsp;&nbsp;&nbsp;
        <li><a href="#" class="text-white">About</a></li>&nbsp;&nbsp;&nbsp;
        <li><a href="#" class="text-white">Gallery</a></li>&nbsp;&nbsp;&nbsp;
        <li><a href="#" class="text-white">Video</a></li>&nbsp;&nbsp;&nbsp;
        <li><a href="#" class="text-white">Blog</a></li>&nbsp;&nbsp;&nbsp;
        <li><a href="#" class="text-white">Contact</a></li>
      </ul>
</div>

<div class="ml-28 font-bold ambass">
<p>Join us as Campus</p>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ambassador</p>
</div>

<div class="ml-4 text-white joinb mt-1">
<button>Join Now</button>
</div>

</div>

    </nav>

    
</body>


</html>

<?php /**PATH C:\laravel_ntpl\grassroots\resources\views/front-end/header.blade.php ENDPATH**/ ?>