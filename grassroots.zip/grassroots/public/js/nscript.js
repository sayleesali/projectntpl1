// Define speed of scroll in milliseconds
const scrollSpeed = 2000;

// Get testimonial container
const testimonialContainer = document.querySelector('.testimonial-container');

// Clone first testimonial and append it to the end
testimonialContainer.appendChild(testimonialContainer.firstElementChild.cloneNode(true));

// Set initial scroll position
let scrollPosition = 0;

// Function to scroll testimonials vertically
function scrollTestimonials() {
  // Increment scroll position
  scrollPosition += 1;

  // Check if scrolled to the end
  if (scrollPosition >= testimonialContainer.scrollHeight / 2) {
    // Reset scroll position
    scrollPosition = 0;
    // Reset scroll instantly
    testimonialContainer.scrollTop = 0;
    // Wait for a short delay before scrolling again
    setTimeout(scrollTestimonials, 1000);
  } else {
    // Scroll down by 1 pixel
    testimonialContainer.scrollTop = scrollPosition;
    // Call the function recursively after a short delay
    setTimeout(scrollTestimonials, scrollSpeed / testimonialContainer.scrollHeight);
  }
}


// Function to apply or remove blur effect on first and last testimonial
function blurTestimonial(blur) {
  const testimonials = document.querySelectorAll('.testimonial');
  testimonials[0].classList.toggle('blur', blur); // Apply blur to first testimonial
  testimonials[testimonials.length - 1].classList.toggle('blur', blur); // Apply blur to last testimonial
}


// Start scrolling testimonials
scrollTestimonials();
